from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import pandas as pd
import os

app = Flask(__name__)
app.secret_key = "your_secret_key"  # Needed to use flash messages

# Path to the Excel file
EXCEL_FILE = "orders.xlsx"


# Route for the main page
@app.route("/")
def home():
    return render_template("index.html")


# Route for handling the order submission
@app.route("/order", methods=["POST"])
def order():
    # Retrieve form data
    name = request.form.get("name")  # Get the customer's name
    coffee_type = request.form.get("coffee-type")
    size = request.form.get("size")
    add_ons = request.form.getlist("add-ons")
    quantity = request.form.get("quantity")

    # Check if any required data is missing
    if not name or not coffee_type or not size or not quantity:
        flash("All fields are required!", "danger")
        return redirect(url_for("home"))

    # Calculate total price
    price = calculate_price(size, quantity)

    # Order details as a dictionary
    order_details = {
        "Customer Name": name,
        "Coffee Type": coffee_type,
        "Size": size,
        "Add-Ons": ", ".join(add_ons),
        "Quantity": quantity,
        "Total Price": price,
    }

    # Save the order to a text file
    save_order_to_file(order_details)

    # Save the order to an Excel file
    save_order_to_excel(order_details)

    # Show a flash message as feedback
    flash(f"Order received! Thanks for ordering, {name}.", "success")

    # Redirect to the order details page to display the order summary
    return render_template("order_details.html", order_details=order_details)


# Function to save order details to a text file
def save_order_to_file(order_details):
    with open("orders.txt", "a") as file:
        file.write(f"Name: {order_details['Customer Name']}\n")
        file.write(f"Coffee Type: {order_details['Coffee Type']}\n")
        file.write(f"Size: {order_details['Size']}\n")
        file.write(f"Add-Ons: {order_details['Add-Ons']}\n")
        file.write(f"Quantity: {order_details['Quantity']}\n")
        file.write(f"Price: {order_details['Total Price']}\n")
        file.write("-" * 30 + "\n")


# Function to save order details to an Excel file
def save_order_to_excel(order_details):
    # Define the column names for the DataFrame
    columns = ["Customer Name", "Coffee Type", "Size", "Add-Ons", "Quantity", "Total Price"]

    try:
        # Check if the Excel file exists
        if os.path.exists(EXCEL_FILE):
            # Load existing data
            df = pd.read_excel(EXCEL_FILE)

            # Ensure the DataFrame has the correct columns
            if set(df.columns) != set(columns):
                df = pd.DataFrame(columns=columns)  # Recreate the DataFrame with correct columns if necessary

            # Convert the order details into a DataFrame and append it
            new_order = pd.DataFrame([order_details], columns=columns)
            df = pd.concat([df, new_order], ignore_index=True)
        else:
            # If the file doesn't exist, create a new DataFrame with the correct columns
            df = pd.DataFrame([order_details], columns=columns)

        # Save the DataFrame back to the Excel file
        df.to_excel(EXCEL_FILE, index=False)

    except Exception as e:
        flash(f"Error saving the order to Excel: {str(e)}", "danger")
        print(f"Error: {str(e)}")


# Function to calculate the price (simple example)
def calculate_price(size, quantity):
    price_per_size = {"Small": 69, "Medium": 129, "Large": 199}
    return price_per_size.get(size, 60) * int(quantity)


# Route for handling subscription to the newsletter
@app.route("/subscribe", methods=["POST"])
def subscribe():
    email = request.form.get("email")  # Get the user's email input

    flash(f"Subscription successful! Thank you for subscribing, {email}.", "success")

    return redirect(url_for("news_and_offers"))


# Route for handling callback requests
@app.route("/request_callback", methods=["GET", "POST"])
def request_callback():
    if request.method == "POST":
        # Retrieve form data for the callback request
        name = request.form.get("name")  # Get the customer's name
        phone_number = request.form.get("phone")  # Get the customer's phone number
        preferred_time = request.form.get("time")  # Get preferred time for callback

        # Check if any required data is missing
        if not name or not phone_number or not preferred_time:
            flash("All fields are required!", "danger")
            return redirect(url_for("request_callback"))

        # Callback request details as a dictionary
        callback_details = {
            "Customer Name": name,
            "Phone Number": phone_number,
            "Preferred Time": preferred_time,
        }

        # Save the callback request to the Excel file
        save_callback_to_excel(callback_details)

        # Show a flash message as feedback
        flash("Callback request received! We will contact you soon.", "success")

        # Redirect to the thank you page
        return redirect(url_for("thank_you"))

    # Render the callback form
    return render_template("request_callback.html")


# Function to save callback request details to an Excel file
def save_callback_to_excel(callback_details):
    # Define the column names for the DataFrame
    columns = ["Customer Name", "Phone Number", "Preferred Time"]

    try:
        # Check if the Excel file exists
        if os.path.exists(EXCEL_FILE):
            # Load existing data
            df = pd.read_excel(EXCEL_FILE)

            # Ensure the DataFrame has the correct columns
            if set(df.columns) != set(columns):
                df = pd.DataFrame(columns=columns)  # Recreate the DataFrame with correct columns if necessary

            # Convert the callback details into a DataFrame and append it
            new_callback = pd.DataFrame([callback_details], columns=columns)
            df = pd.concat([df, new_callback], ignore_index=True)
        else:
            # If the file doesn't exist, create a new DataFrame with the correct columns
            df = pd.DataFrame([callback_details], columns=columns)

        # Save the DataFrame back to the Excel file
        df.to_excel(EXCEL_FILE, index=False)

    except Exception as e:
        flash(f"Error saving the callback request to Excel: {str(e)}", "danger")
        print(f"Error: {str(e)}")


# Thank-you route after form submission
@app.route("/thank_you")
def thank_you():
    return "Thank you! We will call you at your preferred time."


# Route to display news and offers
@app.route("/news_and_offers")
def news_and_offers():
    news_and_offers = [
        {"title": "New Espresso Blend!", "description": "Special offer - only Rs 80 this week!"},
        {"title": "Holiday Discount", "description": "20% off on all beverages until December 25!"},
        {"title": "Loyalty Program", "description": "Earn points with every purchase to redeem discounts!"},
    ]
    return render_template("news_and_offers.html", news_and_offers=news_and_offers)


if __name__ == "__main__":
    app.run(debug=True)